import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-utility-detail',
  templateUrl: './utility-detail.component.html',
  styleUrls: ['./utility-detail.component.css']
})
export class UtilityDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
